/****************************************************************************
** Meta object code from reading C++ file 'communicationlib.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../communicationlib.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'communicationlib.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_CommunicationLib_t {
    QByteArrayData data[14];
    char stringdata[93];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CommunicationLib_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CommunicationLib_t qt_meta_stringdata_CommunicationLib = {
    {
QT_MOC_LITERAL(0, 0, 16), // "CommunicationLib"
QT_MOC_LITERAL(1, 17, 6), // "CLopen"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 4), // "type"
QT_MOC_LITERAL(4, 30, 5), // "char*"
QT_MOC_LITERAL(5, 36, 3), // "arg"
QT_MOC_LITERAL(6, 40, 4), // "int*"
QT_MOC_LITERAL(7, 45, 6), // "handle"
QT_MOC_LITERAL(8, 52, 7), // "CLwrite"
QT_MOC_LITERAL(9, 60, 4), // "data"
QT_MOC_LITERAL(10, 65, 7), // "maxSize"
QT_MOC_LITERAL(11, 73, 7), // "CLclose"
QT_MOC_LITERAL(12, 81, 4), // "open"
QT_MOC_LITERAL(13, 86, 6) // "CLStop"

    },
    "CommunicationLib\0CLopen\0\0type\0char*\0"
    "arg\0int*\0handle\0CLwrite\0data\0maxSize\0"
    "CLclose\0open\0CLStop"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CommunicationLib[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    3,   39,    2, 0x0a /* Public */,
       8,    3,   46,    2, 0x0a /* Public */,
      11,    1,   53,    2, 0x0a /* Public */,
      12,    0,   56,    2, 0x0a /* Public */,
      13,    0,   57,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, 0x80000000 | 4, 0x80000000 | 6,    3,    5,    7,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 4, QMetaType::Int,    7,    9,   10,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void CommunicationLib::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        CommunicationLib *_t = static_cast<CommunicationLib *>(_o);
        switch (_id) {
        case 0: _t->CLopen((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< char*(*)>(_a[2])),(*reinterpret_cast< int*(*)>(_a[3]))); break;
        case 1: _t->CLwrite((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< char*(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 2: _t->CLclose((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->open(); break;
        case 4: _t->CLStop(); break;
        default: ;
        }
    }
}

const QMetaObject CommunicationLib::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_CommunicationLib.data,
      qt_meta_data_CommunicationLib,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *CommunicationLib::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CommunicationLib::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_CommunicationLib.stringdata))
        return static_cast<void*>(const_cast< CommunicationLib*>(this));
    return QObject::qt_metacast(_clname);
}

int CommunicationLib::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
    return _id;
}
struct qt_meta_stringdata_AppThread_t {
    QByteArrayData data[14];
    char stringdata[65];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AppThread_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AppThread_t qt_meta_stringdata_AppThread = {
    {
QT_MOC_LITERAL(0, 0, 9), // "AppThread"
QT_MOC_LITERAL(1, 10, 1), // "O"
QT_MOC_LITERAL(2, 12, 0), // ""
QT_MOC_LITERAL(3, 13, 4), // "type"
QT_MOC_LITERAL(4, 18, 5), // "char*"
QT_MOC_LITERAL(5, 24, 3), // "arg"
QT_MOC_LITERAL(6, 28, 4), // "int*"
QT_MOC_LITERAL(7, 33, 6), // "handle"
QT_MOC_LITERAL(8, 40, 1), // "W"
QT_MOC_LITERAL(9, 42, 4), // "data"
QT_MOC_LITERAL(10, 47, 7), // "maxSize"
QT_MOC_LITERAL(11, 55, 1), // "C"
QT_MOC_LITERAL(12, 57, 2), // "op"
QT_MOC_LITERAL(13, 60, 4) // "Stop"

    },
    "AppThread\0O\0\0type\0char*\0arg\0int*\0"
    "handle\0W\0data\0maxSize\0C\0op\0Stop"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AppThread[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    3,   39,    2, 0x06 /* Public */,
       8,    3,   46,    2, 0x06 /* Public */,
      11,    1,   53,    2, 0x06 /* Public */,
      12,    0,   56,    2, 0x06 /* Public */,
      13,    0,   57,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, 0x80000000 | 4, 0x80000000 | 6,    3,    5,    7,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 4, QMetaType::Int,    7,    9,   10,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void AppThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        AppThread *_t = static_cast<AppThread *>(_o);
        switch (_id) {
        case 0: _t->O((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< char*(*)>(_a[2])),(*reinterpret_cast< int*(*)>(_a[3]))); break;
        case 1: _t->W((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< char*(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 2: _t->C((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->op(); break;
        case 4: _t->Stop(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (AppThread::*_t)(int , char * , int * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AppThread::O)) {
                *result = 0;
            }
        }
        {
            typedef void (AppThread::*_t)(int , char * , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AppThread::W)) {
                *result = 1;
            }
        }
        {
            typedef void (AppThread::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AppThread::C)) {
                *result = 2;
            }
        }
        {
            typedef void (AppThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AppThread::op)) {
                *result = 3;
            }
        }
        {
            typedef void (AppThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AppThread::Stop)) {
                *result = 4;
            }
        }
    }
}

const QMetaObject AppThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_AppThread.data,
      qt_meta_data_AppThread,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *AppThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AppThread::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_AppThread.stringdata))
        return static_cast<void*>(const_cast< AppThread*>(this));
    return QThread::qt_metacast(_clname);
}

int AppThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void AppThread::O(int _t1, char * _t2, int * _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void AppThread::W(int _t1, char * _t2, int _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void AppThread::C(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void AppThread::op()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void AppThread::Stop()
{
    QMetaObject::activate(this, &staticMetaObject, 4, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
