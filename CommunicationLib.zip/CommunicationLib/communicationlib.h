#ifndef COMMUNICATIONLIB_H
#define COMMUNICATIONLIB_H

#include "communicationlib_global.h"
#include "commulib.h"
#include <QMap>
#include <windows.h>  
#include <QCoreApplication>
#include <QThread>
#include <QObject>
#include <QDebug>
#include <QTime>


class COMMUNICATIONLIB_EXPORT CommunicationLib : public QObject
{
	Q_OBJECT
public:
	CommunicationLib();
	~CommunicationLib();
	CommuLib* liv;
	QCoreApplication* a;
public slots:
	void CLopen(int type, char* arg, int *handle);
	void CLwrite(int handle, char* data, int maxSize);
	void CLclose(int handle);
	void CLStop();
	
private:

};


class AppThread : public QThread
{
	Q_OBJECT
	
	void run() Q_DECL_OVERRIDE;

public:
	AppThread() {}
	~AppThread() {
		
		qDebug() << "quit1"; 
		
		qDebug() << "quit2";
		
	}
	
signals:
	void O(int type, char* arg, int *handle);
	void W(int handle, char* data, int maxSize);
	void C(int handle);
	void Stop();
};



extern "C" COMMUNICATIONLIB_EXPORT int  Create(int type);

extern "C" COMMUNICATIONLIB_EXPORT int	Open(int type, char* arg);

extern "C" COMMUNICATIONLIB_EXPORT void Close(int handle);

extern "C" COMMUNICATIONLIB_EXPORT bool Write(int handle, char* data, int maxSize);

extern "C" COMMUNICATIONLIB_EXPORT bool InstallCallBack(int handle, void* callback);

extern "C" COMMUNICATIONLIB_EXPORT void UnInit(void);
#endif // COMMUNICATIONLIB_H
