#include "commulib.h"
#include <QDebug>

CommuLib::CommuLib(CommType::Comm_Type type)
	/*: QMainWindow(parent)*/
{

	CommunicationType = new CommType(type);

	if (type == CommType::Comm_Type::U_SerialPort)
	{
		serialport = new QSerialPort();
		connect(serialport, SIGNAL(readyRead()), this, SLOT(CommuLibRead()));
	}

	
}

CommuLib::~CommuLib()
{

}

bool	CommuLib::CommuLibOpen(char* arg)
{
	if (CommunicationType->UseType == CommType::Comm_Type::U_SerialPort)
	{
		QString str(arg);
		//QString str("com1,9600,1,2,");//str = "com2,9600,8,0,0,0,";
		QRegExp rx("([^,]+),");
		QStringList strList;
		int pos = 0;

		while ((pos = rx.indexIn(str, pos)) != -1)
		{
			strList << rx.cap(1);
			pos += rx.matchedLength();
			qDebug() << rx.cap(1);
		}

		CommunicationType->U_Serial_Port->PortName			= strList.at(0);
		CommunicationType->U_Serial_Port->Baud_Rate			= strList.at(1).toInt();
		CommunicationType->U_Serial_Port->Data_Bits			= (Serial_PortType::DataBits)strList.at(2).toInt();
		CommunicationType->U_Serial_Port->Flow_Control		= (Serial_PortType::FlowControl)strList.at(3).toInt();
		CommunicationType->U_Serial_Port->U_Parity			= (Serial_PortType::Parity)strList.at(4).toInt();
		CommunicationType->U_Serial_Port->Stop_Bits			= (Serial_PortType::StopBits)strList.at(5).toInt();
		
		return Serial_Port::SerialPortOpen(serialport, CommunicationType);
	}

	return true;
}



bool CommuLib::CommuLibWrite(const char * data,qint64 maxSize)
{
	if (CommunicationType->UseType == CommType::Comm_Type::U_SerialPort)
	{
		if (serialport->write(data, maxSize) == -1)
		{
			return false;
		}
	}

	return true;
}

void CommuLib::CommuLibClose()
{
	Serial_Port::SerialPortClose(serialport);
}

void CommuLib::CommuLibRead(void)
{
	qDebug() << "CommuLibRead";
	QByteArray ReadData = serialport->readAll();
	CallBack(ReadData.data(), ReadData.size());
}

bool CommuLib::CommuLibInstallCallBack(void* callback)
{
	CallBack = (CallBackFunc)callback;
	return true;
}


bool Serial_Port::SerialPortOpen(QSerialPort	*serialport, CommType* type)
{
	bool re ;
	serialport->setPortName		(type->U_Serial_Port->PortName);
	serialport->setBaudRate		(type->U_Serial_Port ->Baud_Rate);
	serialport->setDataBits		((QSerialPort::DataBits)type->U_Serial_Port->Data_Bits);
	serialport->setFlowControl	((QSerialPort::FlowControl)type->U_Serial_Port->Flow_Control);
	serialport->setParity		((QSerialPort::Parity)type->U_Serial_Port->U_Parity);
	serialport->setStopBits		((QSerialPort::StopBits)type->U_Serial_Port->Stop_Bits);
	re = serialport->open		(QIODevice::ReadWrite);
	return re;
}

bool Serial_Port::SerialPortClose(QSerialPort	*serialport)
{
	
	serialport->close();
	return true;
}