#include "commtype.h"

CommType::CommType(Comm_Type type)
{
	if (type == Comm_Type::U_SerialPort)
	{
		U_Serial_Port = new Serial_PortType();
		UseType			= Comm_Type::U_SerialPort;
	}
	else if (type == Comm_Type::U_TCP)
	{

	}
}

CommType::~CommType()
{

}
