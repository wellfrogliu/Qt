#ifndef COMMTYPE_H
#define COMMTYPE_H

#include <QString>

class Serial_PortType;

class CommType
{
public:
	enum Comm_Type{ U_SerialPort, U_TCP, U_UDP };
public:
	CommType(Comm_Type type);
	~CommType();

private:

public:
	Comm_Type	UseType;
	/*SerialPort*/
	Serial_PortType	*U_Serial_Port;
	
};

class Serial_PortType
{
public:
	enum	DataBits	{ Data5 = 5,Data6 = 6,Data7 = 7,Data8 = 8};
	enum	FlowControl { NoFlowControl, HardwareControl, SoftwareControl};
	enum	Parity		{ NoParity, EvenParity, OddParity, SpaceParity, MarkParity};
	enum	StopBits	{ OneStop, OneAndHalfStop, TwoStop};

	QString			PortName;
	int				Baud_Rate;
	DataBits		Data_Bits;
	FlowControl		Flow_Control;
	Parity			U_Parity;
	StopBits		Stop_Bits;
	

};

#endif // COMMTYPE_H
