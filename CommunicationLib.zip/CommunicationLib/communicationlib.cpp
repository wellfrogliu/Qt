#include "communicationlib.h"
//#include <QtWidgets/QApplication>


CommunicationLib *q;
QMap <int, CommuLib*> map;
AppThread *thread;

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpvReserved*/)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		qDebug() << "DLL_PROCESS_ATTACH";
		thread = new AppThread;
		thread->start();
		//_CrtSetBreakAlloc(951);
		
	}
	if (dwReason == DLL_PROCESS_DETACH )
	{
	
		delete q;
		delete thread;
		
	}

	

	return TRUE;
}

CommuLib* GetClass(int handle)
{
	CommuLib* liv = map.value(handle);
	return liv;
}

CommunicationLib::CommunicationLib()
{

}

CommunicationLib::~CommunicationLib()
{

}

void CommunicationLib::CLopen(int type, char* arg, int *handle)
{
	qDebug() << "CLopen1";
	CommuLib* liv = new CommuLib((CommType::Comm_Type)type);
	if (liv->CommuLibOpen(arg))
	{
		if (!map.isEmpty())
		{
			*handle = map.lastKey() + 1;
		}
		else
		{
			*handle = 0;
		}
		map.insert(*handle, liv);
	}
	
	qDebug() << "CLopen" << *handle;
}

void CommunicationLib::CLwrite(int handle, char* data, int maxSize)
{
	CommuLib* liv = GetClass(handle);  
	liv->CommuLibWrite(data, maxSize);
	qDebug() << "LVwrite";
}

void CommunicationLib::CLclose(int handle)
{
	CommuLib* liv = GetClass(handle);
	liv->CommuLibClose();
	delete liv;
	qDebug() << "delete liv";
	map.remove(handle);

}

void CommunicationLib::CLStop()
{
	qDebug() << "CLStop1";
	a->quit();
	qDebug() << "CLStop2";
}

void AppThread::run ()
{
	int argc = 1;
	char *argv[] = { "1" };
	QCoreApplication app(argc, argv);
	
	CommunicationLib p;
	p.a = &app;
	
	connect(this, SIGNAL(O(int, char*, int*)), &p, SLOT(CLopen(int, char*, int*)));
	connect(this, SIGNAL(W(int, char*, int)), &p, SLOT(CLwrite(int, char*, int)));
	connect(this, SIGNAL(C(int)), &p, SLOT(CLclose(int)));
	connect(this, SIGNAL(Stop()), &p, SLOT(CLStop()));

	p.a->exec();
	qDebug() << "run";
}



int  Create(int type)
{
	CommuLib* liv = new CommuLib((CommType::Comm_Type)type);
	int handle = 0;
	if (!map.isEmpty())
	{
		handle = map.lastKey() + 1;
	}
	else
	{
		handle = 0;
	}

	map.insert(handle, liv);
	return handle;
}

int Open(int type, char* arg)
{
	
	
	int handle = -1;
	//CommuLib* liv = new CommuLib((CommType::Comm_Type)type);
	//if (liv->CommuLibOpen("com2, 9600, 8, 0, 0, 0,"))
	//{
	//	if (!map.isEmpty())
	//	{
	//		handle = map.lastKey() + 1;
	//	}
	//	else
	//	{
	//		handle = 0;
	//	}
	//	map.insert(handle, liv);
	//}
	////liv->CommuLibWrite("hello LV", 8);
	//emit thread->op();
	emit thread->O(0, "com2, 9600, 8, 0, 0, 0,", &handle);

	QTime dieTime = QTime::currentTime().addMSecs(200);
	while (QTime::currentTime() < dieTime)
	{
		;
	}
	qDebug() << "open" << handle;
	return handle;
	
}

void Close(int handle)
{
	
	emit thread->C(handle);
	
}

bool Write(int handle, char* data, int maxSize)
{
	/*CommuLib* liv = GetClass(handle);
	return liv->CommuLibWrite(data, maxSize);*/
	emit thread->W(handle, data, maxSize);
	/*q->open();*/
	return true;
}

bool InstallCallBack(int handle, void* callback)
{
	CommuLib* liv = GetClass(handle);
	return liv->CommuLibInstallCallBack(callback);

}

void UnInit(void)
{
	emit thread->Stop();
	while (thread->isRunning());
}
