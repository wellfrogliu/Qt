#ifndef COMMULIB_H
#define COMMULIB_H


#include <QSerialPort>
#include "commtype.h"
#include <QObject>

class Serial_Port;


class CommuLib : public QObject
{
	Q_OBJECT


	typedef void(*CallBackFunc)(char *data, qint64 maxSize);

public:
	CommuLib(CommType::Comm_Type type);
	~CommuLib();
	

private:
	
	//CommType	*CommunicationType;
	QSerialPort	*serialport;
	CallBackFunc CallBack;

public:
	CommType	*CommunicationType;

public:
	bool CommuLibInstallCallBack(void* callback);
	bool CommuLibOpen(char* arg);
	bool CommuLibWrite(const char * data, qint64 maxSize);
	void CommuLibClose();

public slots:
	void CommuLibRead(void);
	
};

class Serial_Port
{
public:
static	bool SerialPortOpen (QSerialPort	*serialport, CommType* type);
static	bool SerialPortClose(QSerialPort	*serialport);
};

#endif // COMMULIB_H
